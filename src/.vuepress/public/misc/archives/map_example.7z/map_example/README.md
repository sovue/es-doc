## Создание собственной карты на примере мода «7 Дней Лета»

- `code/map/map.rpy` — реализация карты alt1 (обычная)
- `code/map/map_big.rpy` — реализация карты alt2 (большая)
- `code/labels/normal.rpy` — пример использования alt1
- `code/labels/big.rpy` — пример использования alt2
- изображения — в `images/map/normal`, `images/map/big` и `images/chibis`

### Что такое alt1 и alt2

- alt1 — «обычная» карта. Все имена зон и ресурсов имеют суффикс `_alt1`.
- alt2 — «большая» карта. Все имена зон и ресурсов имеют суффикс `_alt2`.

Каждая карта полностью независима: у неё свои изображения, свои списки зон и свои функции.

## 1. Ресурсы

Структура папок для карт и чибиков в примере:

- `images/map/normal/` — фон и маски «обычной» карты
  - `bg.jpg` — основа карты
  - `avaliable.jpg` — «кликабельные» участки (idle-состояние)
  - `selected.jpg` — «подсветка» при наведении (hover)
- `images/map/big/` — фон и маски «большой» карты (те же три файла)
- `images/chibis/` — изображения чибиков, задаются в `store.map_chibi_7dl` и скейлятся до 40x40 при использовании в alt2, в alt1 без масштабирования

## 2. Добавьте изображения карт

В коде это делается словарями `store.map_pics_alt1` и `store.map_pics_alt2`:

- в `code/map/map.rpy` ищите `store.map_pics_alt1`
- в `code/map/map_big.rpy` ищите `store.map_pics_alt2`

Ключи одинаковы по смыслу, но с разными суффиксами:

- `bgpic_alt1`/`bgpic_alt2` — файл подложки
- `avaliable_alt1`/`avaliable_alt2` — idle-слой кликабельных зон
- `selected_alt1`/`selected_alt2` — hover-слой для наведения

## 3. Добавьте зоны

Список зон — это словарь `store.map_zones_alt1` или `store.map_zones_alt2`.
Каждая зона — запись вида:

- ключ зоны (например, `square_alt1` или `lake_alt2`)
- поля:
  - `position: [x1, y1, x2, y2]` — прямоугольник зоны в пикселях
  - `default_bg: bg_tmp_image(u"Название")` — подпись-заглушка на карте, чтобы показать "временное" изображение, если для указанной зоны нет нужного изображения на карте (полезно, когда готовите свою карту в коде, но нет нужных изображений для отображения позиций на карте).

Посмотрите полный перечень зон прямо в коде:

- alt1: `code/map/map.rpy` в `store.map_zones_alt1`
- alt2: `code/map/map_big.rpy` в `store.map_zones_alt2`

## 4. Инициализируйте карту (один раз за мод)

Инициализация должна вызываться один раз за всё прохождение мода:

- alt1: `init_map_zones_alt1()`
- alt2: `init_map_zones_alt2()`

См. `code/labels/example.rpy` — там обе инициализации вызваны последовательно перед использованием карт.

## 5. Работа с картой

Обе карты предоставляют одинаковые по смыслу функции (с разными суффиксами):

- `disable_all_zones_altX()` / `enable_all_zones_altX()` — выключить/включить все зоны
- `set_zone_altX(name, label)` — включить зону
- `reset_zone_altX(name)` / `enable_empty_zone_altX(name)` — сбросить/включить пустую зону
- `reset_current_zone_altX()` / `disable_current_zone_altX()` — сбросить/выключить текущую активную зону
- `been_there_altX()` — количество визитов в текущую зону (взято из 7ДЛ, полезно для проверки, пришёл ли читатель ещё раз на ту же позицию на карте)
- `set_chibi_altX(name, ch)` / `reset_chibi_altX(name)` — назначить/сбросить чибика на зоне
- `show_map_altX()` — показать карту

`X` — `1` для alt1 и `2` для alt2.

## 6. Пример использования обычной карты

```python
label map_example_normal_prepare:
    $ disable_all_zones_alt1()
    $ disable_all_chibi_alt1()

    $ set_zone_alt1('clubs_alt1', 'map_example_normal_clubs')
    $ set_zone_alt1('camp_entrance_alt1', 'map_example_normal_camp_entrance')
    $ set_zone_alt1('square_alt1', 'map_example_normal_square')
    $ set_chibi_alt1('square_alt1', "sl")

    jump map_example_normal

    return

label map_example_normal:
    play sound sfx_paper_bag
    $ show_map_alt1()
    
    return

label map_example_normal_clubs:
    $ disable_current_zone_alt1()
    "Клубы"
    return
label map_example_normal_camp_entrance:
    $ disable_current_zone_alt1()
    "Ворота"
    return
label map_example_normal_square:
    $ disable_current_zone_alt1()
    "Площадь (с чибиком Слави)"
    return
```

## 7. Пример использования большой карты

```python

label map_example_big_prepare:
    $ disable_all_zones_alt2()
    $ disable_all_chibi_alt2()

    $ set_zone_alt2('clubs_alt2', 'map_example_big_clubs')
    $ set_zone_alt2('camp_entrance_alt2', 'map_example_big_camp_entrance')
    $ set_zone_alt2('square_alt2', 'map_example_big_square')
    $ set_zone_alt2('lake_alt2', 'map_example_big_lake')
    $ set_chibi_alt2('lake_alt2', 'sl')
    $ set_zone_alt2('sports_hall_alt2', 'map_example_sports_hall')
    jump map_example_big

    return

label map_example_big:
    play sound sfx_paper_bag
    $ show_map_alt2()
    
    return

label map_example_big_clubs:
    $ disable_current_zone_alt2()
    "Клубы"
    return
label map_example_big_camp_entrance:
    $ disable_current_zone_alt2()
    "Ворота"
    return
label map_example_big_square:
    $ disable_current_zone_alt2()
    "Площадь"
    return
label map_example_big_lake:
    $ disable_current_zone_alt2()
    "Озеро (с чибиком Слави)"
    return
label map_example_sports_hall:
    $ disable_current_zone_alt2()
    "Спортзал и футбольное поле"
    return
```

## 8. Добавление своих зон и чибиков

- Добавить зону: впишите её в `store.map_zones_altX` c корректным `position` и подписью `default_bg`.
- Прокрасьте соответствующие области на `avaliable.jpg` и `selected.jpg`.
- Добавить чибика: добавьте чибика в `store.map_chibi_7dl` (см. `code/map/map.rpy`), затем назначьте через `set_chibi_altX(zone, key)`.